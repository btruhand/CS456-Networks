Make version used
=================
GNU Make v3.81 

Programming Language
====================
The programs **receiver.js** and **sender.js** were written in Node JS v0.6.12

How to run the programs
=======================
Run the programs in this order:
* ./nEmulator *emulator parameters as outlined by the assignment*
* node receiver.js *receiver parameters as outlined by the assignment*
* node sender.js *receiver parameters as outlined by the assignment*

Testing
=======

The following were the machines used to test the programs:
* Emulator was run on ubuntu1204-002.student.cs.uwaterloo.ca with 
* Receiver (receiver.js) was run on ubuntu1204-004.student.cs.uwaterloo.ca
* Sender (sender.js) was run on ubuntu1204-006.student.cs.uwaterloo.ca
