Make and Programming Language Version
======================================

Make v3.81 was used for this assignment. The code is writtend in Node JS v0.6.12

How to run the Program
======================

1. Issue a make command
2. Run the NSE as the following: ./nse-linux386 <routers_host> <nse_port>
3. Run the script **router** as the following: ./router <router_id> <nse_host> <nse_port> <router_port>,
   in the order of router 1, router 2, router 3, router 4, router 5 on 5 separate terminals

Testing and Building Environment
================================

The program was tested by running 5 router instances according to the procedure above on machine:
**ubuntu1204-002.student.cs.uwaterloo.ca**

The nse was run on machine:
**ubuntu1204-004.student.cs.uwaterloo.ca**
