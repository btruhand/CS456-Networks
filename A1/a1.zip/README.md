To run the server run:
'./server.sh <req_code>'

To run the client run:
'./client.sh <server_address> <n_port> <req_code> <message>'

The client and server were on:
- Client on: ubuntu1204-002, Server on: ubuntu1204-002
- Client on: ubuntu1204-004, Server on: ubuntu1204-002
- Client on: ubuntu1204-002, Server on: ubuntu1204-004

The program was written in Python v2.7.3.
Make version is v3.81. However no need to run make
